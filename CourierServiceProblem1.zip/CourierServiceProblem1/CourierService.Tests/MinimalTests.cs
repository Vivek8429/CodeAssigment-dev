﻿using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace CourierService.Tests;

public class MinimalTests
{
    [Fact]
    public void CostFormula_ShouldMatchPdf()
    {
        var cost = CostCalculator.CalculateDeliveryCost(100, 5, 5);
        Assert.Equal(175, cost);
    }

    [Fact]
    public void Discount_InvalidOfferCode_ShouldBeZero()
    {
        var offers = PdfOffers();
        int discount = DiscountCalculator.CalculateDiscount(1000, 100, 100, "INVALID", offers);
        Assert.Equal(0, discount);
    }

    [Fact]
    public void Discount_OFR001_Distance200_ShouldBeZero()
    {
        var offers = PdfOffers();
        int deliveryCost = CostCalculator.CalculateDeliveryCost(100, 100, 200);
        int discount = DiscountCalculator.CalculateDiscount(deliveryCost, 100, 200, "OFR001", offers);
        Assert.Equal(0, discount);
    }

    [Fact]
    public void Problem1_Sample_ShouldMatchPdf()
    {
        var offers = PdfOffers();
        int baseCost = 100;

        var c1 = CostCalculator.CalculateDeliveryCost(baseCost, 5, 5);
        var d1 = DiscountCalculator.CalculateDiscount(c1, 5, 5, "OFR001", offers);
        Assert.Equal("PKG1 0 175", $"PKG1 {d1} {c1 - d1}");

        var c2 = CostCalculator.CalculateDeliveryCost(baseCost, 15, 5);
        var d2 = DiscountCalculator.CalculateDiscount(c2, 15, 5, "OFR002", offers);
        Assert.Equal("PKG2 0 275", $"PKG2 {d2} {c2 - d2}");

        var c3 = CostCalculator.CalculateDeliveryCost(baseCost, 10, 100);
        var d3 = DiscountCalculator.CalculateDiscount(c3, 10, 100, "OFR003", offers);
        Assert.Equal("PKG3 35 665", $"PKG3 {d3} {c3 - d3}");
    }

    [Fact]
    public void Problem2_SampleDeliveryTimes_ShouldMatchPdf()
    {
        var packages = new List<Package>
        {
            new Package { Id="PKG1", Weight=50,  Distance=30  },
            new Package { Id="PKG2", Weight=75,  Distance=125 },
            new Package { Id="PKG3", Weight=175, Distance=100 },
            new Package { Id="PKG4", Weight=110, Distance=60  },
            new Package { Id="PKG5", Weight=155, Distance=95  },
        };

        DeliveryScheduler.Schedule(packages, vehicleCount: 2, speed: 70, maxLoad: 200);

        AssertApprox(3.98, Get(packages, "PKG1").EstimatedDeliveryTimeHours);
        AssertApprox(1.78, Get(packages, "PKG2").EstimatedDeliveryTimeHours);
        AssertApprox(1.42, Get(packages, "PKG3").EstimatedDeliveryTimeHours);
        AssertApprox(0.85, Get(packages, "PKG4").EstimatedDeliveryTimeHours);
        AssertApprox(4.19, Get(packages, "PKG5").EstimatedDeliveryTimeHours);
    }

    private static Package Get(List<Package> pkgs, string id) => pkgs.Single(p => p.Id == id);

    private static void AssertApprox(double expected, double actual, double tol = 0.01)
    {
        // Compare at 2 decimals (PDF output precision) to avoid floating point boundary issues
        double a = Math.Round(actual, 2, MidpointRounding.AwayFromZero);
        Assert.InRange(a, expected - tol, expected + tol);
    }

    private static IReadOnlyDictionary<string, Offer> PdfOffers()
        => new Dictionary<string, Offer>(System.StringComparer.OrdinalIgnoreCase)
        {
            ["OFR001"] = new Offer { Code = "OFR001", DiscountPercentage = 10, MinWeight = 70, MaxWeight = 200, MinDistance = 0, MaxDistance = 199 },
            ["OFR002"] = new Offer { Code = "OFR002", DiscountPercentage = 7, MinWeight = 100, MaxWeight = 250, MinDistance = 50, MaxDistance = 150 },
            ["OFR003"] = new Offer { Code = "OFR003", DiscountPercentage = 5, MinWeight = 10, MaxWeight = 150, MinDistance = 50, MaxDistance = 250 },
        };
}
