﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace CourierService;

public static class Program
{
    public static void Main(string[] args)
    {
        // Load offers.json (recommended path to avoid working-directory issues)
        string offersPath = args.Length > 0
            ? args[0]
            : Path.Combine(AppContext.BaseDirectory, "offers.json");

        var offersByCode = OfferRepository.LoadOffers(offersPath);

        // Read header: base_cost, package_count
        var header = ReadTokensOrThrow();
        int baseCost = ParseIntOrThrow(header[0], "base_delivery_cost");
        int packageCount = ParseIntOrThrow(header[1], "no_of_packages");

        // Read packages and compute Problem 1 (cost + discount)
        var packagesInOrder = new List<Package>(packageCount);

        for (int i = 0; i < packageCount; i++)
        {
            var t = ReadTokensOrThrow();
            if (t.Length < 4)
                throw new FormatException("Each package line must be: pkg_id weight distance offer_code");

            string pkgId = t[0];
            int weight = ParseIntOrThrow(t[1], $"{pkgId}.weight");
            int distance = ParseIntOrThrow(t[2], $"{pkgId}.distance");
            string offerCode = t[3];

            int deliveryCost = CostCalculator.CalculateDeliveryCost(baseCost, weight, distance);
            int discount = DiscountCalculator.CalculateDiscount(deliveryCost, weight, distance, offerCode, offersByCode);
            int totalCost = deliveryCost - discount;

            packagesInOrder.Add(new Package
            {
                Id = pkgId,
                Weight = weight,
                Distance = distance,
                OfferCode = offerCode,
                DeliveryCost = deliveryCost,
                Discount = discount,
                TotalCost = totalCost
            });
        }

        // Try to read vehicle line (Problem 2)
        // If no vehicle line exists, we output Problem 1 results only.
        string? vehicleLine = Console.ReadLine();
        bool hasProblem2 = !string.IsNullOrWhiteSpace(vehicleLine);

        if (!hasProblem2)
        {
            Console.WriteLine(); // blank line between input and output

            foreach (var p in packagesInOrder)
                Console.WriteLine($"{p.Id} {p.Discount} {p.TotalCost}");

            return;
        }

        // Parse vehicle line: no_of_vehicles max_speed max_carriable_weight
        var vTokens = vehicleLine!.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        if (vTokens.Length < 3)
            throw new FormatException("Vehicle line must be: no_of_vehicles max_speed max_carriable_weight");

        int vehicleCount = ParseIntOrThrow(vTokens[0], "no_of_vehicles");
        int speed = ParseIntOrThrow(vTokens[1], "max_speed");
        int maxLoad = ParseIntOrThrow(vTokens[2], "max_carriable_weight");

        // Compute delivery times (Problem 2)
        DeliveryScheduler.Schedule(packagesInOrder, vehicleCount, speed, maxLoad);

        Console.WriteLine(); // blank line between input and output

        // Output in same order as input
        foreach (var p in packagesInOrder)
            Console.WriteLine($"{p.Id} {p.Discount} {p.TotalCost} {p.EstimatedDeliveryTimeHours:F2}");
    }

    private static string[] ReadTokensOrThrow()
    {
        var line = Console.ReadLine();
        if (string.IsNullOrWhiteSpace(line))
            throw new InvalidOperationException("Unexpected empty input line.");

        var tokens = line.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        if (tokens.Length == 0)
            throw new InvalidOperationException("Invalid input line.");

        return tokens;
    }

    private static int ParseIntOrThrow(string value, string fieldName)
    {
        if (!int.TryParse(value, out int result))
            throw new FormatException($"Invalid integer for '{fieldName}': '{value}'");
        return result;
    }
}

// -------------------- Models --------------------

public sealed class Package
{
    public string Id { get; set; } = "";
    public int Weight { get; set; }
    public int Distance { get; set; }
    public string OfferCode { get; set; } = "";

    public int DeliveryCost { get; set; }
    public int Discount { get; set; }
    public int TotalCost { get; set; }

    public double EstimatedDeliveryTimeHours { get; set; } = 0.0;
}

public sealed class Offer
{
    public string Code { get; set; } = "";
    public int DiscountPercentage { get; set; }

    public int MinWeight { get; set; }
    public int MaxWeight { get; set; }
    public int MinDistance { get; set; }
    public int MaxDistance { get; set; }

    public bool IsEligible(int weight, int distance) =>
        weight >= MinWeight && weight <= MaxWeight &&
        distance >= MinDistance && distance <= MaxDistance;
}

public sealed class Vehicle
{
    public double AvailableAtHours { get; set; } = 0.0;
}

// -------------------- Problem 1 --------------------

public static class CostCalculator
{
    // Delivery Cost = Base + (Weight * 10) + (Distance * 5)
    public static int CalculateDeliveryCost(int baseCost, int weight, int distance)
        => baseCost + (weight * 10) + (distance * 5);
}

public static class DiscountCalculator
{
    public static int CalculateDiscount(
        int deliveryCost,
        int weight,
        int distance,
        string offerCode,
        IReadOnlyDictionary<string, Offer> offersByCode)
    {
        if (string.IsNullOrWhiteSpace(offerCode))
            return 0;

        if (!offersByCode.TryGetValue(offerCode, out var offer))
            return 0;

        if (!offer.IsEligible(weight, distance))
            return 0;

        return (deliveryCost * offer.DiscountPercentage) / 100;
    }
}

public static class OfferRepository
{
    public static IReadOnlyDictionary<string, Offer> LoadOffers(string filePath)
    {
        if (!File.Exists(filePath))
            throw new FileNotFoundException($"Offers file not found: {filePath}");

        string json = File.ReadAllText(filePath);
        var offers = JsonSerializer.Deserialize<List<Offer>>(json, new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        }) ?? new();

        var dict = new Dictionary<string, Offer>(StringComparer.OrdinalIgnoreCase);
        foreach (var offer in offers)
        {
            if (!string.IsNullOrWhiteSpace(offer.Code))
                dict[offer.Code.Trim()] = offer;
        }

        return dict;
    }
}

// -------------------- Problem 2 --------------------

public static class DeliveryScheduler
{
    public static void Schedule(List<Package> packagesInOrder, int vehicleCount, int speed, int maxLoad)
    {
        if (vehicleCount <= 0) throw new ArgumentOutOfRangeException(nameof(vehicleCount));
        if (speed <= 0) throw new ArgumentOutOfRangeException(nameof(speed));
        if (maxLoad <= 0) throw new ArgumentOutOfRangeException(nameof(maxLoad));

        if (packagesInOrder.Any(p => p.Weight > maxLoad))
            throw new InvalidOperationException("At least one package exceeds max vehicle load and can never be shipped.");

        var remaining = new List<Package>(packagesInOrder);

        var vehicles = new List<Vehicle>(vehicleCount);
        for (int i = 0; i < vehicleCount; i++)
            vehicles.Add(new Vehicle());

        while (remaining.Count > 0)
        {
            // Pick earliest available vehicle
            var vehicle = vehicles.OrderBy(v => v.AvailableAtHours).First();
            double startTime = vehicle.AvailableAtHours;

            // Build best shipment according to PDF rules
            var shipment = ShipmentPlanner.BuildBestShipment(remaining, maxLoad);
            if (shipment.Count == 0)
                throw new InvalidOperationException("No feasible shipment could be formed.");

            int maxDistance = shipment.Max(p => p.Distance);

            // PDF-style: truncate travel time to 2 decimals
            double tripTime = Trunc2(maxDistance / (double)speed);

            // Set delivery time per package (truncate distance/speed, then truncate final)
            foreach (var pkg in shipment)
            {
                double travel = Trunc2(pkg.Distance / (double)speed);
                pkg.EstimatedDeliveryTimeHours = Trunc2(startTime + travel);
            }

            // Vehicle returns and becomes available again (truncate final availability)
            vehicle.AvailableAtHours = Trunc2(startTime + Trunc2(2.0 * tripTime));

            // Remove shipped packages
            var shipped = new HashSet<string>(shipment.Select(p => p.Id), StringComparer.OrdinalIgnoreCase);
            remaining.RemoveAll(p => shipped.Contains(p.Id));
        }
    }



    private static double Trunc2(double value)
    {
        // Truncate to 2 decimals using decimal arithmetic to avoid double precision artifacts.
        decimal d = (decimal)value;
        d = Math.Floor(d * 100m) / 100m;
        return (double)d;
    }

}

public static class ShipmentPlanner
{
    // Rule priority:
    // 1) Maximize number of packages in shipment
    // 2) If tie, maximize total weight
    // 3) If tie, choose shipment delivered first (smaller farthest distance)
    public static List<Package> BuildBestShipment(List<Package> remaining, int maxLoad)
    {
        int n = remaining.Count;

       
        // If n is large, fall back to greedy.
        if (n > 20)
            return GreedyShipment(remaining, maxLoad);

        List<Package> best = new();
        int bestCount = 0;
        int bestWeight = 0;
        int bestMaxDistance = int.MaxValue;

        // Enumerate subsets
        for (int mask = 1; mask < (1 << n); mask++)
        {
            int totalWeight = 0;
            int maxDistance = 0;
            int count = 0;

            // Quick build subset
            for (int i = 0; i < n; i++)
            {
                if ((mask & (1 << i)) == 0) continue;

                totalWeight += remaining[i].Weight;
                if (totalWeight > maxLoad) break; // prune
                maxDistance = Math.Max(maxDistance, remaining[i].Distance);
                count++;
            }

            if (totalWeight > maxLoad) continue;

            bool better =
                count > bestCount ||
                (count == bestCount && totalWeight > bestWeight) ||
                (count == bestCount && totalWeight == bestWeight && maxDistance < bestMaxDistance);

            if (better)
            {
                bestCount = count;
                bestWeight = totalWeight;
                bestMaxDistance = maxDistance;

                var subset = new List<Package>();
                for (int i = 0; i < n; i++)
                    if ((mask & (1 << i)) != 0)
                        subset.Add(remaining[i]);

                best = subset;
            }
        }

        return best;
    }

    private static List<Package> GreedyShipment(List<Package> remaining, int maxLoad)
    {
        // Greedy fallback: maximize count (lightest first), then weight by trying to add heavier ones if possible.
        var sorted = remaining.OrderBy(p => p.Weight).ThenBy(p => p.Distance).ToList();

        int sum = 0;
        var shipment = new List<Package>();
        foreach (var p in sorted)
        {
            if (sum + p.Weight > maxLoad) continue;
            shipment.Add(p);
            sum += p.Weight;
        }

        return shipment;
    }



    

}


